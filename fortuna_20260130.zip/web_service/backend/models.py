# python_service/models.py

from datetime import datetime, date
from decimal import Decimal
from typing import Annotated, Any, Callable, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, WrapSerializer


def decimal_serializer(value: Decimal, handler: Callable[[Decimal], Any]) -> Any:
    """Custom serializer for Decimal to float conversion."""
    return float(value)


JsonDecimal = Annotated[Decimal, WrapSerializer(decimal_serializer, when_used="json")]


# --- Configuration for Aliases (BUG #4 Fix) ---
class FortunaBaseModel(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
    )


# --- Core Data Models ---
class OddsData(FortunaBaseModel):
    win: Optional[JsonDecimal] = None
    place: Optional[JsonDecimal] = None
    show: Optional[JsonDecimal] = None
    source: str
    last_updated: datetime


class Runner(FortunaBaseModel):
    id: Optional[str] = None
    name: str
    number: Optional[int] = Field(None, alias="saddleClothNumber")
    scratched: bool = False
    odds: Dict[str, OddsData] = {}
    jockey: Optional[str] = None
    trainer: Optional[str] = None


class Race(FortunaBaseModel):
    id: str
    venue: str
    race_number: int = Field(..., alias="raceNumber")
    start_time: datetime = Field(..., alias="startTime")
    runners: List[Runner]
    source: str
    field_size: Optional[int] = None
    qualification_score: Optional[float] = Field(None, alias="qualificationScore")
    favorite: Optional[Runner] = None
    race_name: Optional[str] = None
    distance: Optional[str] = None
    is_error_placeholder: bool = Field(False, alias="isErrorPlaceholder")
    error_message: Optional[str] = Field(None, alias="errorMessage")
    metadata: Dict[str, Any] = {}


class SourceInfo(FortunaBaseModel):
    name: str
    status: str
    races_fetched: int = Field(..., alias="racesFetched")
    fetch_duration: float = Field(..., alias="fetchDuration")
    error_message: Optional[str] = Field(None, alias="errorMessage")
    attempted_url: Optional[str] = Field(None, alias="attemptedUrl")


class AdapterError(FortunaBaseModel):
    adapter_name: str = Field(..., alias="adapterName")
    error_message: str = Field(..., alias="errorMessage")
    attempted_url: Optional[str] = Field(None, alias="attemptedUrl")


class AggregatedResponse(FortunaBaseModel):
    race_date: Optional[date] = Field(None, alias="date")
    races: List[Race]
    errors: List[AdapterError]
    source_info: List[SourceInfo] = Field(..., alias="sourceInfo")
    metadata: Dict[str, Any] = {}


class QualifiedRacesResponse(FortunaBaseModel):
    criteria: Dict[str, Any]
    races: List[Race]


class TipsheetRace(FortunaBaseModel):
    race_id: str = Field(..., alias="raceId")
    track_name: str = Field(..., alias="trackName")
    race_number: int = Field(..., alias="raceNumber")
    post_time: str = Field(..., alias="postTime")
    score: float
    factors: Any  # JSON string stored as Any


class ManualParseRequest(FortunaBaseModel):
    adapter_name: str
    html_content: str = Field(..., max_length=5_000_000)  # ~5MB limit
