# web_service/backend/version.py

__version__ = "3.0.1" # Default version

def get_version():
    """Returns the application version."""
    return __version__
