
import json
from collections import defaultdict

def generate_grid():
    try:
        with open('qualified_races.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        print("Error: qualified_races.json not found. Run fortuna_reporter.py first.")
        return

    races = data.get('races', [])
    
    # Track -> FieldSize -> Count
    stats = defaultdict(lambda: defaultdict(int))
    all_field_sizes = set()
    
    for race in races:
        track = race.get('venue', 'Unknown')
        # Count only non-scratched runners
        field_size = len([r for r in race.get('runners', []) if not r.get('scratched', False)])
        
        stats[track][field_size] += 1
        all_field_sizes.add(field_size)
    
    sorted_field_sizes = sorted(list(all_field_sizes))
    sorted_tracks = sorted(stats.keys())
    
    # Print Header
    header = f"{'Track':<25} | " + " | ".join([f"{fs:2}" for fs in sorted_field_sizes])
    print(header)
    print("-" * len(header))
    
    for track in sorted_tracks:
        row = f"{track[:25]:<25} | "
        row_vals = []
        for fs in sorted_field_sizes:
            val = stats[track].get(fs, 0)
            row_vals.append(f"{val:2}" if val > 0 else "  ")
        print(row + " | ".join(row_vals))

if __name__ == "__main__":
    generate_grid()
