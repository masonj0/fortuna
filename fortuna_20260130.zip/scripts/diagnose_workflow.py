#!/usr/bin/env python3
"""
Workflow Diagnostic Parser

Ingests artifacts from the unified-race-report workflow and produces
a consolidated troubleshooting report.

Usage:
    python scripts/diagnose_workflow.py [--artifacts-dir DIR] [--output FORMAT]
    
Arguments:
    --artifacts-dir: Directory containing downloaded artifacts (default: current dir)
    --output: Output format - 'markdown', 'json', or 'both' (default: both)
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any
from dataclasses import dataclass, field, asdict


@dataclass
class DiagnosticSection:
    """A section of the diagnostic report."""
    name: str
    status: str  # 'ok', 'warning', 'error', 'unknown'
    summary: str
    details: list[str] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass 
class DiagnosticReport:
    """Complete diagnostic report."""
    timestamp: str
    run_number: str
    overall_status: str
    sections: list[DiagnosticSection] = field(default_factory=list)
    errors_found: list[dict] = field(default_factory=list)
    warnings_found: list[dict] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return asdict(self)


class WorkflowDiagnosticParser:
    """Parses workflow artifacts and generates diagnostic reports."""
    
    # Common error patterns to search for
    ERROR_PATTERNS = [
        (r'Traceback \(most recent call last\)', 'Python Exception'),
        (r'Error:', 'General Error'),
        (r'Exception:', 'Exception'),
        (r'FAILED', 'Test/Check Failed'),
        (r'ConnectionError', 'Network Connection Error'),
        (r'TimeoutError|timed? ?out', 'Timeout'),
        (r'MemoryError|Out of memory|OOM|oom-killer', 'Memory Issue'),
        (r'Permission denied', 'Permission Error'),
        (r'No such file or directory', 'File Not Found'),
        (r'ImportError|ModuleNotFoundError', 'Import Error'),
        (r'SIGKILL|SIGTERM|killed', 'Process Killed'),
        (r'playwright.*error|browser.*crash', 'Browser Error'),
        (r'display.*not.*found|cannot open display', 'Display Error'),
    ]
    
    # Warning patterns
    WARNING_PATTERNS = [
        (r'Warning:', 'General Warning'),
        (r'deprecated', 'Deprecation Warning'),
        (r'retry|retrying', 'Retry Attempt'),
        (r'slow|timeout approaching', 'Performance Warning'),
        (r'disk space|storage', 'Storage Warning'),
    ]
    
    def __init__(self, artifacts_dir: str = "."):
        self.artifacts_dir = Path(artifacts_dir)
        self.report = DiagnosticReport(
            timestamp=datetime.utcnow().isoformat() + "Z",
            run_number=self._detect_run_number(),
            overall_status="unknown"
        )
        
    def _detect_run_number(self) -> str:
        """Try to detect run number from artifact names."""
        for item in self.artifacts_dir.iterdir():
            if match := re.search(r'-(\d+)$', item.name):
                return match.group(1)
        return "unknown"
    
    def _read_file(self, *path_parts: str) -> str | None:
        """Safely read a file, returning None if not found."""
        filepath = self.artifacts_dir.joinpath(*path_parts)
        if filepath.exists():
            try:
                return filepath.read_text(encoding='utf-8', errors='replace')
            except Exception as e:
                return f"[Error reading file: {e}]"
        return None
    
    def _read_json(self, *path_parts: str) -> dict | list | None:
        """Safely read and parse a JSON file."""
        content = self._read_file(*path_parts)
        if content and not content.startswith("[Error"):
            try:
                return json.loads(content)
            except json.JSONDecodeError:
                return None
        return None
    
    def _find_files(self, pattern: str) -> Path | list[Path]:
        """Find files matching a glob pattern."""
        return list(self.artifacts_dir.rglob(pattern))
    
    def _search_patterns(self, content: str, patterns: list[tuple[str, str]]) -> list[dict]:
        """Search content for patterns and return matches with context."""
        matches = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines):
            for pattern, category in patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    # Get context (2 lines before and after)
                    start = max(0, i - 2)
                    end = min(len(lines), i + 3)
                    context = lines[start:end]
                    
                    matches.append({
                        'category': category,
                        'line_number': i + 1,
                        'line': line.strip()[:200],  # Truncate long lines
                        'context': '\n'.join(context)[:500],  # Truncate context
                        'pattern': pattern
                    })
                    break  # One match per line
                    
        return matches
    
    def parse_setup_diagnostics(self) -> DiagnosticSection:
        """Parse setup job diagnostics."""
        section = DiagnosticSection(
            name="Setup Phase",
            status="unknown",
            summary=""
        )
        
        # Check for env context
        env_context = self._read_file("env_context.log")
        execution_mode = self._read_file("execution_mode.log")
        
        if env_context:
            section.details.append("Environment context captured")
            
            # Extract key metrics
            if match := re.search(r'Run ID: (\d+)', env_context):
                section.metrics['run_id'] = match.group(1)
            if match := re.search(r'GitHub Event: (\w+)', env_context):
                section.metrics['event_type'] = match.group(1)
                
            section.status = "ok"
        else:
            section.status = "warning"
            section.details.append("Environment context log not found")
            
        if execution_mode:
            section.details.append("Execution mode determined")
            
            # Extract mode info
            if "Run Canary: true" in execution_mode:
                section.metrics['canary_enabled'] = True
            if "Run Full: true" in execution_mode:
                section.metrics['full_report_enabled'] = True
                
            if match := re.search(r'Analyzer: (\w+)', execution_mode):
                section.metrics['analyzer'] = match.group(1)
        
        section.summary = f"Setup {'completed' if section.status == 'ok' else 'had issues'}"
        return section
    
    def parse_canary_diagnostics(self) -> DiagnosticSection:
        """Parse canary check diagnostics."""
        section = DiagnosticSection(
            name="Canary Check",
            status="unknown", 
            summary=""
        )
        
        # Look for canary files
        canary_files = {
            'preflight': self._read_file("canary_preflight.log"),
            'execution': self._read_file("canary_execution.log"),
            'failure': self._read_file("canary_failure_diagnostics.log"),
            'result': self._read_json("canary_result.json"),
            'pip_install': self._read_file("canary_pip_install.log"),
            'browser_install': self._read_file("canary_browser_install.log"),
        }
        
        files_found = sum(1 for v in canary_files.values() if v is not None)
        section.metrics['files_found'] = files_found
        
        # Check canary result
        if canary_files['result']:
            result = canary_files['result']
            section.metrics['canary_result'] = result
            
            if isinstance(result, dict) and result.get('health_status') == 'healthy':
                section.status = "ok"
                section.summary = "Canary passed - system healthy"
            else:
                section.status = "error"
                if isinstance(result, dict):
                    section.summary = f"Canary failed: {result.get('error', result.get('message', 'unknown'))}"
                else:
                    section.summary = "Canary failed: Invalid result format"
        
        # Check for failure diagnostics
        if canary_files['failure']:
            section.status = "error"
            section.details.append("Failure diagnostics were captured")
            
            # Look for OOM
            if 'out of memory' in canary_files['failure'].lower():
                section.details.append("⚠️ OOM condition detected")
                self.report.errors_found.append({
                    'source': 'canary',
                    'category': 'Memory Issue',
                    'detail': 'Out of memory condition detected'
                })
                
        # Check execution log for errors
        if canary_files['execution']:
            errors = self._search_patterns(canary_files['execution'], self.ERROR_PATTERNS)
            if errors:
                section.details.append(f"Found {len(errors)} error patterns in execution log")
                self.report.errors_found.extend([
                    {**e, 'source': 'canary_execution'} for e in errors[:10]
                ])
        
        # Default status if not set
        if section.status == "unknown":
            if files_found > 0:
                section.status = "ok" if not canary_files['failure'] else "error"
            else:
                section.status = "warning"
                section.summary = "Canary diagnostics not found (may have been skipped)"
                
        return section
    
    def parse_report_generation(self) -> DiagnosticSection:
        """Parse report generation diagnostics."""
        section = DiagnosticSection(
            name="Report Generation",
            status="unknown",
            summary=""
        )
        
        report_files = {
            'preflight': self._read_file("report_preflight.log"),
            'output': self._read_file("reporter_output.log"),
            'execution': self._read_file("reporter_execution.log"),
            'summary': self._read_json("reporter_execution_summary.json"),
            'failure': self._read_file("report_failure_diagnostics.log"),
            'post_state': self._read_file("report_post_state.log"),
            'spotlight': self._read_json("adapter_success_spotlight.json"),
        }
        
        files_found = sum(1 for v in report_files.values() if v is not None)
        section.metrics['files_found'] = files_found
        
        # Check execution summary
        if report_files['summary']:
            summary = report_files['summary']
            if isinstance(summary, dict):
                section.metrics['duration_seconds'] = summary.get('duration_seconds')
                section.metrics['exit_code'] = summary.get('exit_code')
                
                if summary.get('exit_code') == 0:
                    section.status = "ok"
                    duration = summary.get('duration_seconds', 0)
                    section.summary = f"Report generated successfully in {duration}s"
                else:
                    section.status = "error"
                    section.summary = f"Report failed with exit code {summary.get('exit_code')}"
        
        # Check spotlight results
        if report_files['spotlight']:
            spotlight = report_files['spotlight']
            if isinstance(spotlight, dict):
                section.metrics['total_races'] = spotlight.get('total_races', 0)
                section.metrics['successful_adapters'] = spotlight.get('total_successful_adapters', 0)
                section.details.append(
                    f"Results: {spotlight.get('total_races', 0)} races, "
                    f"{spotlight.get('total_successful_adapters', 0)} adapters"
                )
        
        # Check for errors in reporter output
        if report_files['output']:
            output_size = len(report_files['output'])
            section.metrics['output_size_bytes'] = output_size
            
            errors = self._search_patterns(report_files['output'], self.ERROR_PATTERNS)
            warnings = self._search_patterns(report_files['output'], self.WARNING_PATTERNS)
            
            section.metrics['error_count'] = len(errors)
            section.metrics['warning_count'] = len(warnings)
            
            if errors:
                section.details.append(f"Found {len(errors)} errors in output")
                # Add unique errors to report
                seen_categories = set()
                for e in errors:
                    if e['category'] not in seen_categories:
                        self.report.errors_found.append({**e, 'source': 'reporter_output'})
                        seen_categories.add(e['category'])
                        
            if warnings:
                section.details.append(f"Found {len(warnings)} warnings in output")
                
        # Check failure diagnostics
        if report_files['failure']:
            section.status = "error"
            section.details.append("Failure diagnostics were captured")
            
            # Look for specific issues
            failure_content = report_files['failure'].lower()
            if 'oom' in failure_content or 'out of memory' in failure_content:
                self.report.recommendations.append(
                    "Memory issue detected - consider reducing concurrent operations"
                )
            if 'timeout' in failure_content:
                self.report.recommendations.append(
                    "Timeout detected - check network connectivity and increase timeouts"
                )
        
        # Default status
        if section.status == "unknown":
            if report_files['spotlight']:
                section.status = "ok"
                section.summary = "Report appears successful"
            elif files_found > 0:
                section.status = "warning"
                section.summary = "Report ran but results unclear"
            else:
                section.status = "warning"
                section.summary = "Report generation diagnostics not found"
                
        return section
    
    def parse_validation(self) -> DiagnosticSection:
        """Parse validation results."""
        section = DiagnosticSection(
            name="Validation",
            status="unknown",
            summary=""
        )
        
        validation_log = self._read_file("validation_report.log")
        
        if validation_log:
            section.metrics['validation_log_found'] = True
            
            if "VALIDATION PASSED" in validation_log:
                section.status = "ok"
                section.summary = "All validations passed"
            elif "VALIDATION FAILED" in validation_log:
                section.status = "error"
                section.summary = "Validation failed - critical files missing or corrupted"
                
            # Count check results
            passed = validation_log.count("✅")
            failed = validation_log.count("❌")
            warnings = validation_log.count("⚠️")
            
            section.metrics['checks_passed'] = passed
            section.metrics['checks_failed'] = failed  
            section.metrics['checks_warned'] = warnings
            
            section.details.append(f"Checks: {passed} passed, {failed} failed, {warnings} warnings")
        else:
            section.status = "warning"
            section.summary = "Validation report not found"
            
        return section
    
    def parse_security_scan(self) -> DiagnosticSection:
        """Parse security scan results."""
        section = DiagnosticSection(
            name="Security Scan",
            status="unknown",
            summary=""
        )
        
        security_log = self._read_file("security_scan.log")
        
        if security_log:
            section.metrics['security_log_found'] = True
            
            # Look for vulnerability counts
            vuln_matches = re.findall(r'(\d+)\s+vulnerabilit', security_log, re.IGNORECASE)
            if vuln_matches:
                total_vulns = sum(int(v) for v in vuln_matches)
                section.metrics['vulnerabilities_found'] = total_vulns
                
                if total_vulns > 0:
                    section.status = "warning"
                    section.summary = f"Found {total_vulns} potential vulnerabilities"
                else:
                    section.status = "ok"
                    section.summary = "No vulnerabilities detected"
            else:
                section.status = "ok"
                section.summary = "Security scan completed"
        else:
            section.status = "unknown"
            section.summary = "Security scan not run or log not found"
            
        return section
    
    def parse_system_resources(self) -> DiagnosticSection:
        """Analyze system resource usage across all logs."""
        section = DiagnosticSection(
            name="System Resources",
            status="ok",
            summary=""
        )
        
        # Collect memory stats from various logs
        all_logs = []
        for log_file in self._find_files("*.log"):
            if isinstance(log_file, Path):
                content = log_file.read_text(encoding='utf-8', errors='replace')
                all_logs.append(content)
            
        combined = '\n'.join(all_logs)
        
        # Look for memory issues
        memory_issues = []
        if re.search(r'out of memory|oom|memory error', combined, re.IGNORECASE):
            memory_issues.append("OOM detected")
            section.status = "error"
            
        # Look for disk issues
        disk_issues = []
        if re.search(r'no space left|disk full|storage', combined, re.IGNORECASE):
            disk_issues.append("Disk space issue detected")
            section.status = "error"
            
        # Look for process issues
        if re.search(r'zombie|defunct', combined, re.IGNORECASE):
            section.details.append("Zombie processes detected")
            section.status = "warning" if section.status == "ok" else section.status
            
        section.metrics['memory_issues'] = len(memory_issues)
        section.metrics['disk_issues'] = len(disk_issues)
        
        if memory_issues:
            section.details.extend(memory_issues)
        if disk_issues:
            section.details.extend(disk_issues)
            
        if section.status == "ok":
            section.summary = "No resource issues detected"
        elif section.status == "warning":
            section.summary = "Minor resource concerns"
        else:
            section.summary = "Resource issues detected - check details"
            
        return section
    
    def generate_recommendations(self):
        """Generate recommendations based on findings."""
        # Based on errors found
        error_categories = set(e.get('category', '') for e in self.report.errors_found)
        
        if 'Memory Issue' in error_categories:
            self.report.recommendations.append(
                "🧠 Memory issues detected: Consider reducing batch sizes, "
                "adding memory limits, or upgrading runner specs"
            )
            
        if 'Timeout' in error_categories:
            self.report.recommendations.append(
                "⏱️ Timeout issues: Check network connectivity, increase REQUEST_TIMEOUT, "
                "or add retry logic"
            )
            
        if 'Browser Error' in error_categories:
            self.report.recommendations.append(
                "🌐 Browser errors: Verify Playwright installation, check display server, "
                "ensure DISPLAY env var is set"
            )
            
        if 'Display Error' in error_categories:
            self.report.recommendations.append(
                "🖥️ Display issues: Ensure Xvfb is running, verify setup-display action"
            )
            
        if 'Network Connection Error' in error_categories:
            self.report.recommendations.append(
                "🌍 Network issues: Check if target sites are accessible, "
                "consider adding proxy configuration"
            )
            
        if 'Import Error' in error_categories:
            self.report.recommendations.append(
                "📦 Import errors: Verify all dependencies in requirements.txt, "
                "check PYTHONPATH configuration"
            )
            
        # Based on section statuses
        for section in self.report.sections:
            if section.status == "error" and section.name == "Canary Check":
                self.report.recommendations.append(
                    "🐤 Canary failed: Review canary_execution.log for root cause "
                    "before investigating full report"
                )
                
        # Default recommendation if none generated
        if not self.report.recommendations:
            self.report.recommendations.append(
                "✅ No critical issues detected. Review individual section details for optimization opportunities."
            )
    
    def determine_overall_status(self):
        """Determine overall workflow status from sections."""
        statuses = [s.status for s in self.report.sections]
        
        if 'error' in statuses:
            self.report.overall_status = 'error'
        elif 'warning' in statuses:
            self.report.overall_status = 'warning'
        elif all(s == 'ok' for s in statuses):
            self.report.overall_status = 'ok'
        else:
            self.report.overall_status = 'unknown'
    
    def parse_all(self) -> DiagnosticReport:
        """Run all parsers and generate complete report."""
        self.report.sections = [
            self.parse_setup_diagnostics(),
            self.parse_canary_diagnostics(),
            self.parse_report_generation(),
            self.parse_validation(),
            self.parse_security_scan(),
            self.parse_system_resources(),
        ]
        
        self.generate_recommendations()
        self.determine_overall_status()
        
        return self.report
    
    def to_markdown(self) -> str:
        """Generate markdown report."""
        lines = []
        
        # Header
        status_emoji = {
            'ok': '✅',
            'warning': '⚠️', 
            'error': '❌',
            'unknown': '❓'
        }
        
        lines.append(f"# Workflow Diagnostic Report")
        lines.append("")
        lines.append(f"**Generated:** {self.report.timestamp}")
        lines.append(f"**Run Number:** {self.report.run_number}")
        lines.append(f"**Overall Status:** {status_emoji.get(self.report.overall_status, '❓')} {self.report.overall_status.upper()}")
        lines.append("")
        
        # Summary table
        lines.append("## Quick Summary")
        lines.append("")
        lines.append("| Section | Status | Summary |")
        lines.append("|---------|--------|---------|")
        for section in self.report.sections:
            emoji = status_emoji.get(section.status, '❓')
            lines.append(f"| {section.name} | {emoji} {section.status} | {section.summary} |")
        lines.append("")
        
        # Errors if any
        if self.report.errors_found:
            lines.append("## Errors Found")
            lines.append("")
            # Group by category
            by_category = {}
            for error in self.report.errors_found:
                cat = error.get('category', 'Unknown')
                if cat not in by_category:
                    by_category[cat] = []
                by_category[cat].append(error)
                
            for category, errors in by_category.items():
                lines.append(f"### {category} ({len(errors)} occurrences)")
                lines.append("")
                for error in errors[:3]:  # Show max 3 per category
                    lines.append(f"- **Source:** {error.get('source', 'unknown')}")
                    lines.append(f"  - Line: `{error.get('line', 'N/A')[:100]}`")
                    lines.append("")
                if len(errors) > 3:
                    lines.append(f"  _...and {len(errors) - 3} more_")
                    lines.append("")
        
        # Detailed sections
        lines.append("## Detailed Analysis")
        lines.append("")
        
        for section in self.report.sections:
            emoji = status_emoji.get(section.status, '❓')
            lines.append(f"### {emoji} {section.name}")
            lines.append("")
            lines.append(f"**Status:** {section.status}")
            lines.append(f"**Summary:** {section.summary}")
            lines.append("")
            
            if section.metrics:
                lines.append("**Metrics:**")
                for key, value in section.metrics.items():
                    lines.append(f"- {key}: `{value}`")
                lines.append("")
                
            if section.details:
                lines.append("**Details:**")
                for detail in section.details:
                    lines.append(f"- {detail}")
                lines.append("")
        
        # Recommendations
        lines.append("## Recommendations")
        lines.append("")
        for rec in self.report.recommendations:
            lines.append(f"- {rec}")
        lines.append("")
        
        # Footer
        lines.append("---")
        lines.append(f"_Report generated by diagnose_workflow.py_")
        
        return '\n'.join(lines)
    
    def to_json(self) -> str:
        """Generate JSON report."""
        return json.dumps(self.report.to_dict(), indent=2, default=str)


def main():
    parser = argparse.ArgumentParser(description='Parse workflow diagnostics')
    parser.add_argument('--artifacts-dir', default='.', 
                        help='Directory containing artifacts')
    parser.add_argument('--output', choices=['markdown', 'json', 'both'], 
                        default='both', help='Output format')
    
    args = parser.parse_args()
    
    print(f"Parsing artifacts from: {args.artifacts_dir}", file=sys.stderr)
    
    diagnostic_parser = WorkflowDiagnosticParser(args.artifacts_dir)
    report = diagnostic_parser.parse_all()
    
    # Generate outputs
    if args.output in ('markdown', 'both'):
        md_content = diagnostic_parser.to_markdown()
        md_path = Path(args.artifacts_dir) / 'diagnostic_report.md'
        md_path.write_text(md_content)
        print(f"Markdown report: {md_path}", file=sys.stderr)
        
        # Also print to stdout for step summary
        print(md_content)
        
    if args.output in ('json', 'both'):
        json_content = diagnostic_parser.to_json()
        json_path = Path(args.artifacts_dir) / 'diagnostic_report.json'
        json_path.write_text(json_content)
        print(f"JSON report: {json_path}", file=sys.stderr)
    
    # Exit with appropriate code
    if report.overall_status == 'error':
        sys.exit(1)
    elif report.overall_status == 'warning':
        sys.exit(0)  # Warnings don't fail the build
    else:
        sys.exit(0)


if __name__ == '__main__':
    main()
