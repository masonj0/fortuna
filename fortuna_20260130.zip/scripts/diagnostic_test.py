#!/usr/bin/env python3
"""
Fortuna Adapter Diagnostic Tool
Allows for direct testing of individual adapters to verify connectivity and parsing.
"""

import asyncio
import sys
import os
from datetime import datetime
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from web_service.backend.engine import OddsEngine
from web_service.backend.config import get_settings

async def test_adapter(adapter_name: str, date: str = None):
    """Test a specific adapter by name."""
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    print(f"\n{'='*60}")
    print(f"🧪 DIAGNOSTIC: {adapter_name} ({date})")
    print(f"{'='*60}")

    try:
        settings = get_settings()
        engine = OddsEngine(config=settings)
        
        # Check if adapter exists
        # engine.adapters keys are the source_name (e.g. 'AtTheRaces')
        # We try both the class name and source name
        adapter = engine.adapters.get(adapter_name)
        if not adapter:
            # Try mapping common names
            mapping = {
                "AtTheRacesAdapter": "AtTheRaces",
                "SportingLifeAdapter": "SportingLife",
                "EquibaseAdapter": "Equibase",
                "RacingPostB2BAdapter": "RacingPostB2B",
                "TwinSpiresAdapter": "TwinSpires",
                "BrisnetAdapter": "Brisnet"
            }
            mapped_name = mapping.get(adapter_name, adapter_name)
            adapter = engine.adapters.get(mapped_name)

        if not adapter:
            print(f"❌ Error: Adapter '{adapter_name}' not found.")
            print(f"Available: {list(engine.adapters.keys())}")
            return False

        print(f"✅ Adapter initialized: {adapter.source_name}")
        print(f"🔗 Base URL: {adapter.base_url}")
        
        print("\n📡 Fetching data...")
        start_time = datetime.now()
        
        try:
            # We use get_races directly to test the full pipeline
            races = await asyncio.wait_for(adapter.get_races(date), timeout=120)
            duration = (datetime.now() - start_time).total_seconds()
            
            print(f"✅ Fetch complete in {duration:.2f}s")
            print(f"🏁 Races found: {len(races)}")
            
            if races:
                print("\n📋 Sample Results (Top 3):")
                for race in races[:3]:
                    print(f"  - [{race.start_time.strftime('%H:%M')}] {race.venue} (Race {race.race_number}) - {len(race.runners)} runners")
                return True
            else:
                print("\n⚠️  No races found. This could be due to:")
                print("  1. No meetings scheduled for this date.")
                print("  2. Bot detection/WAF blocking the content.")
                print("  3. Parsing logic failure (structure changed).")
                
                # If it's AtTheRaces and it failed, check if we got any debug files
                debug_dir = Path("debug-snapshots") / adapter.source_name.lower()
                if debug_dir.exists():
                    latest = sorted(debug_dir.glob("*.html"), key=os.path.getmtime)
                    if latest:
                        print(f"🔍 Latest debug snapshot: {latest[-1]}")
                
                return False

        except asyncio.TimeoutError:
            print("❌ Error: Request timed out after 120s.")
            return False
        except Exception as e:
            print(f"❌ Error during fetch: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
            return False
            
    except Exception as e:
        print(f"❌ Error during initialization: {e}")
        return False

async def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/diagnostic_test.py <AdapterName> [YYYY-MM-DD]")
        print("\nExample: python scripts/diagnostic_test.py AtTheRaces")
        sys.exit(1)

    adapter_name = sys.argv[1]
    date = sys.argv[2] if len(sys.argv) > 2 else None
    
    success = await test_adapter(adapter_name, date)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    asyncio.run(main())
