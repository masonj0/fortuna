# Sandbox Verification Guide: Race Discovery Validation

This document provides a detailed walkthrough for verifying that the Fortuna engine is correctly discovering races within the Jules sandbox environment. This process validates the core logic changes that resolved the "0 races" issue and introduces new tools for data analysis and debugging.

## 🚀 The Paradigm Shift: The Sandbox as a Proving Ground

The Jules sandbox is a fully instrumented Linux environment capable of executing the entire Fortuna stack. We no longer need to wait for GitHub Actions to verify connectivity or parsing logic. We can prove success locally using the following tools.

---

## 🛠️ Primary Tools for Verification

### 1. The Scalpel: `scripts/diagnostic_test.py`
This script allows for isolated testing of a single adapter. It bypasses caching and firewall logic to test the raw connectivity and parsing of a source.

**Execution:**
```bash
export PYTHONPATH=$PYTHONPATH:.
python3 scripts/diagnostic_test.py AtTheRaces
python3 scripts/diagnostic_test.py RacingPostB2B
```

**What it verifies:**
- **Connectivity:** Can the adapter reach the source?
- **Parsing:** Can it extract races and runners from the raw HTML/JSON?
- **Debug Snapshots:** If it fails, it saves the raw page to `debug-snapshots/` for forensic analysis.

### 2. The Full Engine: `scripts/fortuna_reporter.py`
This script runs the entire reporting pipeline, including all enabled adapters, the analyzer engine, and artifact generation (HTML/JSON).

**Execution:**
```bash
export ANALYZER_TYPE=simply_success
export FORCE_REFRESH=true
export PYTHONPATH=$PYTHONPATH:.
python3 scripts/fortuna_reporter.py
```

### 3. The Sieve: Automated HTML Cleaning
The system now automatically cleans debug HTML snapshots to remove irrelevant bloat (scripts, styles, SVGs, headers/footers). This reduces 10,000+ lines of noise into a readable document of ~300 lines.

**How it works:**
- Triggered automatically during any fetch or parsing failure if `DEBUG_MODE=true` or in `CI` mode.
- Implemented in `BaseAdapterV3._clean_html_for_debug`.
- Preserves core race data structure while discarding layout bloat, making local debugging much faster.

### 4. The Dashboard: `scripts/generate_race_summary_grid.py`
This script aggregates the results from the reporting pipeline into a high-level summary grid.

**Execution:**
```bash
python3 scripts/generate_race_summary_grid.py
```

**What it verifies:**
Displays a grid of **Race Quantity** by **Field Size** by **Track**. This provides immediate visual confirmation of the diversity and volume of discovered data across global venues.

---

## 📂 Relevant Code Files

The following files constitute the "Heart of Discovery" that was validated:

1.  **`web_service/backend/engine.py`**: The central coordinator. The fix for the `NameError` in `_time_adapter_fetch` was critical for allowing the reporter to finish and display results.
2.  **`python_service/adapters/at_the_races_adapter.py`**: Hardened to propagate `AdapterHttpError` so failures are logged rather than ignored.
3.  **`python_service/adapters/racing_post_b2b_adapter.py`**: Uses the official JSON widget API to bypass standard web-based bot detection.
4.  **`python_service/core/smart_fetcher.py`**: The intelligent fetcher that handles engine fallbacks (HTTPX -> Playwright) and bot detection keywords.
5.  **`python_service/adapters/base_adapter_v3.py`**: Contains the new `_clean_html_for_debug` logic for streamlined troubleshooting.

### 🔗 Raw GitHub Links (Main Branch)
- [engine.py](https://raw.githubusercontent.com/masonj0/fortuna/refs/heads/main/web_service/backend/engine.py)
- [at_the_races_adapter.py](https://raw.githubusercontent.com/masonj0/fortuna/refs/heads/main/python_service/adapters/at_the_races_adapter.py)
- [racing_post_b2b_adapter.py](https://raw.githubusercontent.com/masonj0/fortuna/refs/heads/main/python_service/adapters/racing_post_b2b_adapter.py)
- [smart_fetcher.py](https://raw.githubusercontent.com/masonj0/fortuna/refs/heads/main/python_service/core/smart_fetcher.py)

---

## 📊 Verification Evidence (Sandbox Results - Jan 30, 2026)

During the verification run on Jan 30, 2026, the following metrics were achieved in the sandbox:
- **AtTheRaces:** 171 races discovered.
- **RacingPostB2B:** 71 races discovered.
- **Total Qualified Races:** 242.
- **Artifacts Generated:** `race-report.html`, `qualified_races.json`.
