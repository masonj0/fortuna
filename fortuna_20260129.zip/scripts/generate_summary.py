#!/usr/bin/env python3
"""Generate GitHub Actions step summary with SmartFetcher health."""

import json
import os
from datetime import datetime
from pathlib import Path


def main():
    lines = ["## 🐴 Race Report Summary\n"]

    # Metadata & Thresholds
    metadata = {}
    if Path("report-metadata.json").exists():
        try:
            with open("report-metadata.json") as f:
                metadata = json.load(f)
        except:
            pass

    # High-level metrics
    metrics = {}
    if Path("metrics.json").exists():
        try:
            with open("metrics.json") as f:
                metrics = json.load(f)
        except:
            pass

    # Warning Banner
    race_count = metadata.get("race_count", 0)
    if race_count < 2:
        lines.append("> [!WARNING]\n")
        lines.append("> **Low race count detected!** Only {} qualified races found. Upstream sources may be degraded.\n".format(race_count))
    elif metrics.get("errors"):
        lines.append("> [!IMPORTANT]\n")
        lines.append("> Pipeline completed with {} non-fatal warnings.\n".format(len(metrics["errors"])))

    # Run info
    lines.append(f"**Generated:** {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    lines.append(f"**Run Mode:** `{metadata.get('run_mode', 'N/A')}` | **Canary:** `{metadata.get('canary_health', 'N/A')}`")
    lines.append(f"**Duration:** {metrics.get('duration_seconds', 0):.1f}s")
    lines.append("")

    # Results
    if Path("qualified_races.json").exists():
        try:
            with open("qualified_races.json") as f:
                data = json.load(f)
            races = data.get("races", [])

            lines.append("### 📊 Results\n")
            lines.append(f"**Qualified Races:** {len(races)}")

            if races:
                venues = {}
                for race in races:
                    v = race.get("venue", "Unknown")
                    venues[v] = venues.get(v, 0) + 1

                lines.append(f"**Venues:** {len(venues)}")
                lines.append("")
                lines.append("| Venue | Races |")
                lines.append("|-------|-------|")
                for v, c in sorted(venues.items(), key=lambda x: -x[1])[:10]:
                    lines.append(f"| {v} | {c} |")
        except Exception as e:
            lines.append(f"⚠️ Error: {e}")
    else:
        lines.append("### ⚠️ No Results\n")
        lines.append("No qualified races file generated.")

    lines.append("")

    # Adapter Success Summary (Total Races Found)
    if Path("adapter_success_summary.json").exists():
        try:
            with open("adapter_success_summary.json") as f:
                success_data = json.load(f)

            if success_data:
                lines.append("### 🏆 Total Races Found per Adapter\n")
                lines.append("| Adapter | Races | Duration |")
                lines.append("|:---|:---:|:---:|")
                for item in success_data:
                    lines.append(f"| {item['adapter']} | {item['race_count']} | {item['duration_s']}s |")
                lines.append("")
        except:
            pass

    # Browser verification
    if Path("browser_verification.json").exists():
        try:
            with open("browser_verification.json") as f:
                data = json.load(f)
            lines.append("### 🌐 Browser Status\n")

            # Show test results
            for name, result in data.get("tests", {}).items():
                status = "✅" if result.get("passed") else "❌"
                duration = result.get("duration_ms", 0)
                lines.append(f"- {status} **{name}**: {result.get('message', 'N/A')} ({duration:.0f}ms)")

            # Recommendations
            recs = data.get("recommendations", [])
            if recs:
                lines.append("\n**Recommendations:**")
                for rec in recs[:3]:
                    lines.append(f"- {rec.get('message', '')}")
        except:
            pass

    lines.append("")

    # SmartFetcher Health
    if Path("smartfetcher_health.json").exists():
        try:
            with open("smartfetcher_health.json") as f:
                health = json.load(f)

            lines.append("### 🔧 SmartFetcher Health\n")
            if health.get("engines_used"):
                lines.append("**Engines Used:** " + ", ".join(health["engines_used"]))
            else:
                lines.append("*No engine health data captured in this run.*")
        except:
            pass

    lines.append("")

    # Adapter Firewall
    if Path("adapter_stats.json").exists():
        try:
            with open("adapter_stats.json") as f:
                stats = json.load(f)

            firewalled = [s.get('adapter_name') or s.get('name') for s in stats if s.get('consecutive_failures', 0) > 5]
            at_risk = [s.get('adapter_name') or s.get('name') for s in stats if 3 < s.get('consecutive_failures', 0) <= 5]

            if firewalled or at_risk:
                lines.append("### 🔥 Adapter Firewall & Health\n")
                if firewalled:
                    lines.append("**Firewalled (Disabled):**\n")
                    for name in firewalled:
                        lines.append(f"- 🚫 `{name}`")
                if at_risk:
                    lines.append("\n**At Risk (Close to firewall):**\n")
                    for name in at_risk:
                        lines.append(f"- ⚠️ `{name}`")
                lines.append("")
        except:
            pass

    lines.append("\n---")
    lines.append("*Generated by Fortuna Race Pipeline*")

    print("\n".join(lines))


if __name__ == "__main__":
    main()
