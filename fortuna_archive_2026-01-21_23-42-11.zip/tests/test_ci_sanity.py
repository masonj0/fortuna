def test_ci_pipeline_is_alive():
    """Basic TDD sanity check to ensure pytest is running in CI."""
    assert True