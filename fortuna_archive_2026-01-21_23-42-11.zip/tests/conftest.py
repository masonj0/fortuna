import sys
import os
import shutil
import pytest
import shutil
from pathlib import Path
from unittest.mock import patch
import asyncio
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock
from decimal import Decimal
from datetime import datetime

# =============================================================================
# 1. SYSTEM PATH INJECTION (The 'ModuleNotFoundError' Killer)
# =============================================================================
# This ensures that 'python_service' and 'web_service' are importable
# regardless of where pytest is run from.
repo_root = Path(__file__).resolve().parents[1]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

# =============================================================================
# 2. MOCK SETTINGS (The 'AttributeError' Killer)
# =============================================================================
class MockSettings:
    """Safe settings that don't require .env files or secrets."""
    API_KEY = "test-override-key-123"
    REDIS_URL = "redis://localhost:6379/0"
    CACHE_ENABLED = True
    HTTP_POOL_CONNECTIONS = 100
    HTTP_MAX_KEEPALIVE = 20
    MAX_CONCURRENT_REQUESTS = 50
    # Add any other required config fields here
    THE_RACING_API_KEY = "test-api-key"
    GREYHOUND_API_URL = "http://test-greyhound-api.com"

@pytest.fixture(scope="session")
def test_settings():
    return MockSettings()

# =============================================================================
# 3. GLOBAL MOCKS (The 'RuntimeError' & 'Connection Refused' Killer)
# =============================================================================
@pytest.fixture(scope="session", autouse=True)
def mock_dangerous_dependencies():
    """
    Automatically mocks out dangerous background tasks (Redis, DB connections)
    that crash the test runner when the event loop closes.
    """
    # 1. Kill the heavy background initialization task
    p1 = patch("python_service.api._initialize_heavy_resources_sync")
    # 2. Kill the database session generator
    p2 = patch("python_service.db.init.initialize_database")

    mock_init = p1.start()
    mock_db = p2.start()

    yield

    p1.stop()
    p2.stop()

# =============================================================================
# 4. ASYNCIO EVENT LOOP
# =============================================================================
@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the session."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()

# =============================================================================
# 5. FASTAPI APP & CLIENT
# =============================================================================
@pytest.fixture
async def app(mock_dangerous_dependencies, test_settings):
    from python_service.api import app as fastapi_app
    from python_service.api import get_settings
    from python_service.engine import OddsEngine
    from python_service.manual_override_manager import ManualOverrideManager

    # Override the get_settings dependency
    fastapi_app.dependency_overrides[get_settings] = lambda: test_settings

    # Manually run startup events
    await fastapi_app.router.startup()

    # Attach a mock engine to the app state
    fastapi_app.state.engine = OddsEngine(config=test_settings)
    fastapi_app.state.manual_override_manager = ManualOverrideManager()

    yield fastapi_app

    # Manually run shutdown events
    await fastapi_app.router.shutdown()

    # Clear the dependency override
    fastapi_app.dependency_overrides = {}

@pytest.fixture
async def client(app):
    from httpx import AsyncClient
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac

# =============================================================================
# 6. CACHE FIXTURE (The 'fixture not found' Killer)
# =============================================================================
CACHE_DIR = Path("python_service/cache")

@pytest.fixture(autouse=True)
def clear_cache():
    """
    Ensures a clean slate for both file-based and in-memory caches.
    This is critical to prevent state leakage between tests.
    """
    from python_service.cache_manager import cache_manager

    # Clear in-memory cache before the test
    cache_manager.memory_cache.clear()

    # Clear file-based cache
    if CACHE_DIR.exists():
        shutil.rmtree(CACHE_DIR)

    yield

    # Clear both again after the test to be thorough
    cache_manager.memory_cache.clear()
    if CACHE_DIR.exists():
        shutil.rmtree(CACHE_DIR)

# =============================================================================
# 7. DATA HELPERS (The Logic Validator)
# =============================================================================
def create_mock_race(source, venue, race_number, start_time, runners_data):
    """
    Creates a standardized race object compatible with the OddsEngine.
    Handles the Pydantic model structure required for aggregation.
    """
    # We return a Dict that mimics the Pydantic model structure.
    # This is often safer for tests than instantiating complex models directly.

    runners = []
    if not runners_data:
        runners_data.append({"number": 1, "name": "Test Horse", "odds": "1.0"})
    for r in runners_data:
        # Construct the nested odds dictionary: { 'Source': { 'win': Decimal(...) } }
        odds_struct = {
            source: {
                "win": Decimal(str(r.get("odds", "0.0"))),
                "source": source,
                "last_updated": datetime.now(),
            }
        }

        runners.append({
            "number": r['number'],
            "name": r['name'],
            "odds": odds_struct
        })

    return {
        "id": f"{venue}_{race_number}_{start_time}",
        "venue": venue,
        "race_number": race_number,
        "start_time": start_time,
        "source": source,  # Critical for deduplication logic
        "runners": runners
    }

# Helper to inject settings into tests if needed
def get_test_settings():
    return MockSettings()